from setuptools import setup, find_packages

setup(
    name="darwinpyspark",
    version="0.1.0",
    author="Harry Hands",
    author_email="harry.hands@v7labs.com",
    description="A package for interacting with the V7 platform via Pyspark",
    packages=find_packages(),
    install_requires=[
        "pyspark",
        "requests"
    ]
)